.. SPDX-License-Identifier: CC-BY-SA-4.0

.. _internal-api:

Internal API Reference
======================

:: Placeholder for Doxygen documentation
