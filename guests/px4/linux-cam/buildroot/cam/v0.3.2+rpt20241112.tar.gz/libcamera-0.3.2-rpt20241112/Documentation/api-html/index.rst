.. SPDX-License-Identifier: CC-BY-SA-4.0

.. _api:

API Reference
=============

:: Placeholder for Doxygen documentation
